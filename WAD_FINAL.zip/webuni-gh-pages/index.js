var express = require("express")
var bodyParser = require("body-parser")
var mongoose = require("mongoose")
const app = express()
app.use(bodyParser.json())
app.use(express.static('pulblic'))
app.use(bodyParser.urlencoded({
extended:true }))

mongoose.connect('mongodb://localhost:27017/registration',{
useNewUrlParser: true,
useUnifiedTopology: true
} , function(err, db){
    if (err) throw err;
});

var db = mongoose.connection;

db.on('error',()=>console.log("Error in Connecting to Database"));
db.once('open',()=>console.log("Connected to Database"))

app.post("/sign_in",(req,res) => {
    var username = req.body.Username;
    var password = req.body.Password;
    var logindata = {
        "username": username,
        "pwd" : password,
    }
    db.collection('login').find(document={$data}, (err,collection)=>{
        if(err){
        throw err;
        }
        console.log(" Login Successfull");
        });
        return res.redirect('login_success.html')
        })
        app.get("/",(req,res)=>{
        res.set({
        "Allow-access-Allow-Origin": '*'
        })
        return res.redirect('SignIn.html');
        })


    

app.post("/register",(req,res)=>{
var FirstName = req.body.FirstName;
var LastName = req.body.LastName;
var EmailId = req.body.EmailID;
var MobileNumber = req.body.MobileNumber;
var Bday = req.body.Birthday;
var BMonth = req.body.BirthdayMonth;
var BYear = req.body.BirthdayYear;
var City = req.body.City;
var State = req.body.State;
var data = {
"fname": FirstName,
"lname" : LastName,
"email" : EmailId,
"phno": MobileNumber,
"birthday" : Bday+" " + BMonth +" " + BYear,
"City" : City,
"state" :State
}
db.collection('student').insertOne(data,(err,collection)=>{
if(err){
throw err;
}
console.log("Record Inserted Successfully");
});
return res.redirect('SignUp.html')
})
app.get("/",(req,res)=>{
res.set({
"Allow-access-Allow-Origin": '*'
})
return res.redirect('registration.html');
}).listen(3000);
console.log("Listening on PORT 3000");